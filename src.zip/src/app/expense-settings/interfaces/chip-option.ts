export interface ChipOption {
  value: string;
  removable: boolean;
}
