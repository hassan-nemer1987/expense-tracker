export interface ExpenseSummary {
  color?: string;
  value: string | number;
  metricTitle: string;
  icon?: string;
}
