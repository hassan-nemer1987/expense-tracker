export interface ChartData {
  name: string;
  y: number;
  value: number;
}
