import { DragAndDropDirective } from './drag-and-drop.directive';

describe('DragAndDropDirective', () => {
  it('should create an instance', () => {
    const directive = new DragAndDropDirective();
    expect(directive).toBeTruthy();
  });
});
